#ifndef QMC_ERRORMODE_H
#define QMC_ERRORMODE_H

namespace integrators
{
    enum ErrorMode : int
    {
        all = 1,
        largest = 2
    };
};

#endif
